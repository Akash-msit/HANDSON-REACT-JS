import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Welcome the first session of React</h1>
    </div>
  );
}

export default App;
